BEGIN TRANSACTION;
CREATE TABLE IF NOT EXISTS "TB_curso" (
	"Id_curso"	INTEGER,
	"departamento"	TEXT NOT NULL,
	PRIMARY KEY("Id_curso" AUTOINCREMENT)
);
CREATE TABLE IF NOT EXISTS "TB_professor" (
	"Id_professor"	INTEGER,
	"formacoes"	TEXT NOT NULL,
	PRIMARY KEY("Id_professor" AUTOINCREMENT)
);
CREATE TABLE IF NOT EXISTS "TB_disciplina" (
	"Id_disciplina"	INTEGER,
	"materia"	TEXT NOT NULL,
	"Id_professor"	INTEGER,
	PRIMARY KEY("Id_disciplina" AUTOINCREMENT),
	FOREIGN KEY("Id_professor") REFERENCES "TB_professor"("Id_professor")
);
CREATE TABLE IF NOT EXISTS "TB_aluno" (
	"Id_aluno"	INTEGER,
	"matricula"	TEXT NOT NULL,
	"Id_curso"	INTEGER,
	PRIMARY KEY("Id_aluno" AUTOINCREMENT),
	FOREIGN KEY("Id_curso") REFERENCES "TB_curso"("Id_curso")
);
CREATE TABLE IF NOT EXISTS "TB_aluno_disciplina" (
	"Id_aluno"	INTEGER,
	"Id_disciplina"	INTEGER,
	"nome"	TEXT NOT NULL,
	PRIMARY KEY("Id_aluno","Id_disciplina"),
	FOREIGN KEY("Id_disciplina") REFERENCES "TB_disciplina"("Id_disciplina"),
	FOREIGN KEY("Id_aluno") REFERENCES "TB_aluno"("Id_aluno")
);
CREATE TABLE IF NOT EXISTS "TB_curso_disciplina" (
	"Id_curso"	INTEGER,
	"Id_disciplina"	INTEGER,
	"sala"	TEXT NOT NULL,
	PRIMARY KEY("Id_curso","Id_disciplina"),
	FOREIGN KEY("Id_disciplina") REFERENCES "TB_disciplina"("Id_disciplina"),
	FOREIGN KEY("Id_curso") REFERENCES "TB_curso"("Id_curso")
);
INSERT INTO "TB_curso" VALUES (1,'Telemática');
INSERT INTO "TB_curso" VALUES (2,'Engenharia de Software');
INSERT INTO "TB_professor" VALUES (1,'Mestrado');
INSERT INTO "TB_disciplina" VALUES (1,'Banco de dados',1);
INSERT INTO "TB_disciplina" VALUES (2,'Programação Orientada a Objetos',1);
INSERT INTO "TB_aluno" VALUES (1,'20232011',1);
INSERT INTO "TB_aluno_disciplina" VALUES (1,2,'Geográfia');
INSERT INTO "TB_curso_disciplina" VALUES (2,1,'BC-07');
COMMIT;
